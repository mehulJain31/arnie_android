package com.repmonk.arnie_android;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by mehuljain on 1/5/18.
 */

public class trackworkout extends AppCompatActivity
{

    public void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.trackworkout);


    }
}
