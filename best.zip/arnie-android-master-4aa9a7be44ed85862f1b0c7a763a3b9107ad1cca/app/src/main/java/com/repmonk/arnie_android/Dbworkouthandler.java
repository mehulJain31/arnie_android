
package com.repmonk.arnie_android;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;




public class Dbworkouthandler extends SQLiteOpenHelper
{


    public static final String DATABASE_NAME = "workout5.db";
    public static final String TABLE_NAME = "workout_table2";
    public static final String COL_1 = "serialno";
    public static final String COL_2 = "uniqueid";
    public static final String COL_3 = "_body_type";
    public static final String COL_4 = "name";

    String body_type;


    public Dbworkouthandler(Context context)
    {

        super(context, DATABASE_NAME, null, 2);

    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase)
       {
        sqLiteDatabase.execSQL("CREATE TABLE " + TABLE_NAME + "( serialno INTEGER PRIMARY KEY  AUTOINCREMENT NOT NULL,   uniqueid  VARCHAR(10),  _body_type  VARCHAR(10),  name  VARCHAR(10))");
    }


    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1)
       {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(sqLiteDatabase);
       }


    public boolean insertData(String type2,String name1)

    {
        body_type=type2;
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        String sql1="INSERT INTO  "+TABLE_NAME+"  (uniqueid , _body_type, name) VALUES('1234','"+type2+"',"+"'"+name1+"'"+")";
        sqLiteDatabase.execSQL(sql1);


        long result = sqLiteDatabase.insert(TABLE_NAME, null, contentValues);

        if (result == -1)
            return false;
        else
            return true;

    }


    public Cursor getData(String body_type)
    {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        String query = ("SELECT name From " + TABLE_NAME+" WHERE _body_type = '"+body_type+"'");  // make this query by defining new variables
        Cursor data = sqLiteDatabase.rawQuery(query, null);
        return data;
    }



}


