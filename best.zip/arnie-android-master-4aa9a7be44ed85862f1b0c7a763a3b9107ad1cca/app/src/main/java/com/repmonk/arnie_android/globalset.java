package com.repmonk.arnie_android;

import android.content.Intent;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Created by mehuljain on 1/3/18.
 */

public class globalset
{
    public static ArrayList<String> allworkout = new ArrayList<String>();public static Set<String> copydelete = new LinkedHashSet<String>(allworkout);
    static ArrayList<String> selectedItems_chest = new ArrayList<String>();
    static ArrayList<String> selectedItems_shoulder = new ArrayList<String>();
    static ArrayList<String> selectedItems_arms = new ArrayList<String>();
    static ArrayList<String> selectedItems_legs = new ArrayList<String>();
    static ArrayList<String> selectedItems_back = new ArrayList<String>();
    static ArrayList<String> selectedItems_abs = new ArrayList<String>();






}




